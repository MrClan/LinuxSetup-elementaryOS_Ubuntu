export default {
    groupStages: [
        {
            matchID: "russia-saudi-06-14-2018",
            groupName: "Group A",
            teamA: {
                name: "Russia",
                flag: "RU.png"
            },
            teamB: {
                name: "Saudi Arabia",
                flag: "SA.png"
            },
            startTimeInGMT: "2018-06-14T15:00:00+00:00",
            stadium: "Russia National Stadium",
            city: "Moscow",
            country: "Russia",
            matchTrivia: [
                "This is the first time they are playing aganist each other in the history of FIFA World cups",
                "Very special match this is.",
                "Match with highest number of attendances ever in any russian stadium"
            ]
        },
        {
            matchID: "egypt-uruguay-06-15-2018",
            groupName: "Group B",
            teamA: {
                name: "Egypt",
                flag: "EG.png"
            },
            teamB: {
                name:"Uruguay",
                flag: "BR.png"
            },
            startTimeInGMT: "2018-06-15T15:00:00+00:00",
            
            stadium: "Russia National Stadium",
            city: "Moscow",
            country: "Russia",
            matchTrivia: [
                "Some interesting trivia about this match between these two teams. More interesting the fact, the better it is. We can also add many trivias here and the app can randomly choose one to show to the user",
                "Another very interesting fact about this match",
                "yet another interesting fact"
            ]
        },
    ]
}