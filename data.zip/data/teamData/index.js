import portugal from './portugal'
import germany from './germany'
import argentina from './argentina'
import brazil from './brazil'

// la aba her hai yaha
// if I've 100 teams, I'll have to keep on adding each file here for eg.
// and so on. 
// but this is not what I want
// as I should be able to import the individual class directly in my TeamView.vue file 



export default {
  portugal: portugal,
  germany: germany,
  brazil: brazil,
  argentina: argentina
}
