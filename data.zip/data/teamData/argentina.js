export default {
  "teamName": "Argentina"
}
