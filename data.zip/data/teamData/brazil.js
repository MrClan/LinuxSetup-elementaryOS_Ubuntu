export default {
  "teamName": "Brazil"
}
