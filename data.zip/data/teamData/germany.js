export default {
  "teamName": "Germany"
}
