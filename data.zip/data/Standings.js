export default {
    groups: [
        {
            name: "Group A",
            teams: [
                {
                    name: "Egypt",
                    flag: "EG.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Russia",
                    flag: "RU.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Saudi Arabia",
                    flag:"SA.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Uruguay",
                    flag:"UR.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group B",
            teams: [
                {
                    name: "Iran",
                    flag:"IR.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Morocco",
                    flag:"MO.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Portugal",
                    flag:"PT.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Spain",
                    flag:"ES.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group C",
            teams: [
                {
                    name: "Australia",
                    flag:"AU.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Denmark",
                    flag:"DE.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "France",
                    flag:"FR.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Peru",
                    flag:"PE.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group D",
            teams: [
                {
                    name: "Argentina",
                    flag:"AG.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Croatia",
                    flag:"CR.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Iceland",
                    flag:"IC.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Nigeria",
                    flag:"NG.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group E",
            teams: [
                {
                    name: "Brazil",
                    flag:"BR.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Costa Rica",
                    flag:"CR.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Switzerland",
                    flag:"SW.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Serbia",
                    flag:"SE.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group F",
            teams: [
                {
                    name: "Germany",
                    flag:"DE.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "South Korea",
                    flag:"SK.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Mexico",
                    flag:"ME.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Sweden",
                    flag:"SW.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group G",
            teams: [
                {
                    name: "Belgium",
                    flag:"BE.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "England",
                    flag:"EN.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Panama",
                    flag:"PA.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Tunisia",
                    flag:"TU.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        },
        {
            name: "Group H",
            teams: [
                {
                    name: "Colombia",
                    flag:"CO.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Japan",
                    flag:"JP.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Poland",
                    flag:"PO.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                },
                {
                    name: "Senegal",
                    flag:"SE.png",
                    mp: 0,
                    w: 0,
                    d: 0,
                    l: 0,
                    gf: 0,
                    ga: 0,
                    gd: 0,
                    pts: 0
                }
            ]
        }
    ]
}